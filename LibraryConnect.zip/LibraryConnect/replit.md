# Library Management System

## Overview

A modern library management system built with React, Express, and PostgreSQL. The application enables digital library operations including book cataloging, student registration, book issuance tracking, and return management. It provides a streamlined alternative to manual registry systems for schools and colleges.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool and development server
- Wouter for lightweight client-side routing
- TanStack Query (React Query) for server state management and data fetching
- React Hook Form with Zod for form validation and schema validation

**UI Component System:**
- Radix UI primitives for accessible, unstyled components
- shadcn/ui component library (New York style variant)
- Tailwind CSS for utility-first styling with custom design tokens
- CSS variables for theming (light/dark mode support)

**Design Decisions:**
- Component-based architecture with reusable UI primitives
- Path aliases (@, @shared, @assets) for clean imports
- Form state managed through React Hook Form with Zod schema validation
- Optimistic UI updates through React Query mutations
- Single-page application with client-side routing

### Backend Architecture

**Technology Stack:**
- Node.js with Express framework
- TypeScript for type safety across the stack
- ESBuild for production bundling
- TSX for development execution

**API Design:**
- RESTful API structure with `/api` prefix
- JSON request/response format
- Centralized route registration in `server/routes.ts`
- Request logging middleware with response capture
- Body parsing with raw body preservation for webhook support

**Storage Layer:**
- Interface-based storage abstraction (`IStorage`)
- In-memory storage implementation (`MemStorage`) for development
- UUID-based entity identification
- Schema validation using Drizzle-Zod

**Architecture Patterns:**
- Repository pattern through storage interface
- Middleware-based request processing
- Centralized error handling with Zod validation
- Raw body capture for third-party integrations

### Database Schema

**Technology:**
- PostgreSQL as the primary database
- Drizzle ORM for type-safe database operations
- Drizzle Kit for schema migrations

**Entity Models:**

1. **Books Table:**
   - ID (UUID primary key)
   - Title, Author, ISBN
   - Publisher, Publication Year
   - Quantity and Available count tracking

2. **Students Table:**
   - ID (UUID primary key)
   - Name, Student ID (unique)
   - Email, Phone
   - Department

3. **Issued Books Table:**
   - ID (UUID primary key)
   - Foreign keys to Books and Students
   - Issue Date, Expected Return Date, Actual Return Date
   - Status tracking (active, returned, overdue)
   - Notes field for additional information

**Design Decisions:**
- Text fields for flexible data storage (quantities, dates stored as strings)
- UUID generation at database level using `gen_random_uuid()`
- Foreign key constraints for referential integrity
- Composite tracking through status field for issue state management

### Development Environment

**Build Configuration:**
- Separate development and production modes
- Hot Module Replacement (HMR) in development
- Vite middleware integration with Express
- Development-only Replit plugins (Cartographer, Dev Banner, Error Modal)

**File Structure:**
- `/client` - React frontend application
- `/server` - Express backend application  
- `/shared` - Shared TypeScript schemas and types
- `/migrations` - Database migration files

## External Dependencies

### Core Services
- **Neon Database** - Serverless PostgreSQL hosting (@neondatabase/serverless)
- **PostgreSQL** - Primary relational database

### Third-Party Libraries

**Frontend:**
- Radix UI - Accessible component primitives (accordion, dialog, dropdown, etc.)
- TanStack Query - Server state management
- React Hook Form - Form state and validation
- Zod - Schema validation
- date-fns - Date manipulation
- Embla Carousel - Carousel functionality
- CMDK - Command menu interface
- class-variance-authority & clsx - Conditional styling utilities

**Backend:**
- Drizzle ORM - Type-safe database operations
- connect-pg-simple - PostgreSQL session store
- Express - Web server framework

**Development Tools:**
- Vite - Frontend build tool and dev server
- ESBuild - Backend bundling
- TypeScript - Type checking
- Tailwind CSS - Utility-first styling
- PostCSS with Autoprefixer - CSS processing

### Configuration Requirements
- `DATABASE_URL` environment variable for PostgreSQL connection
- Replit-specific environment detection (`REPL_ID`)
- Node environment configuration (`NODE_ENV`)