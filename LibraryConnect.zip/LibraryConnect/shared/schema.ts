import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const books = pgTable("books", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  author: text("author").notNull(),
  isbn: text("isbn"),
  publisher: text("publisher"),
  publicationYear: text("publication_year"),
  quantity: text("quantity").default("1"),
  available: text("available").default("1"),
});

export const students = pgTable("students", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  studentId: text("student_id").notNull().unique(),
  email: text("email"),
  phone: text("phone"),
  department: text("department"),
});

export const issuedBooks = pgTable("issued_books", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  bookId: varchar("book_id").notNull().references(() => books.id),
  studentId: varchar("student_id").notNull().references(() => students.id),
  issueDate: text("issue_date").notNull(),
  expectedReturnDate: text("expected_return_date"),
  actualReturnDate: text("actual_return_date"),
  status: text("status").notNull().default("active"), // active, returned, overdue
  notes: text("notes"),
});

export const insertBookSchema = createInsertSchema(books).omit({
  id: true,
  available: true,
});

export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
});

export const insertIssuedBookSchema = createInsertSchema(issuedBooks).omit({
  id: true,
});

export type InsertBook = z.infer<typeof insertBookSchema>;
export type Book = typeof books.$inferSelect;
export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type Student = typeof students.$inferSelect;
export type InsertIssuedBook = z.infer<typeof insertIssuedBookSchema>;
export type IssuedBook = typeof issuedBooks.$inferSelect;

// Extended types for frontend display
export type IssuedBookWithDetails = IssuedBook & {
  bookTitle: string;
  bookAuthor: string;
  studentName: string;
  studentIdDisplay: string;
};
