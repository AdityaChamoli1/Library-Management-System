import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  BookOpen, 
  Users, 
  FileText, 
  Plus, 
  Search, 
  Eye, 
  Trash2, 
  CheckCircle, 
  Info, 
  Filter, 
  Download,
  Bell
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { insertBookSchema, insertStudentSchema, insertIssuedBookSchema } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Book, Student, IssuedBookWithDetails } from "@shared/schema";

export default function Home() {
  const { toast } = useToast();
  const [bookSearchTerm, setBookSearchTerm] = useState("");
  const [studentSearchTerm, setStudentSearchTerm] = useState("");
  const [isAddBookOpen, setIsAddBookOpen] = useState(false);
  const [isAddStudentOpen, setIsAddStudentOpen] = useState(false);
  const [recordFilter, setRecordFilter] = useState("all");

  // Queries
  const { data: stats, isLoading: statsLoading } = useQuery<{ totalBooks: number; totalStudents: number; issuedBooks: number }>({
    queryKey: ["/api/stats"],
  });

  const { data: books, isLoading: booksLoading } = useQuery<Book[]>({
    queryKey: ["/api/books"],
  });

  const { data: students, isLoading: studentsLoading } = useQuery<Student[]>({
    queryKey: ["/api/students"],
  });

  const { data: issuedBooks, isLoading: issuedBooksLoading } = useQuery<IssuedBookWithDetails[]>({
    queryKey: ["/api/issued-books"],
  });

  // Forms
  const addBookForm = useForm({
    resolver: zodResolver(insertBookSchema),
    defaultValues: {
      title: "",
      author: "",
      isbn: "",
      publisher: "",
      publicationYear: "",
      quantity: "1",
    },
  });

  const addStudentForm = useForm({
    resolver: zodResolver(insertStudentSchema),
    defaultValues: {
      name: "",
      studentId: "",
      email: "",
      phone: "",
      department: "",
    },
  });

  const issueBookForm = useForm({
    resolver: zodResolver(insertIssuedBookSchema.extend({
      expectedReturnDate: insertIssuedBookSchema.shape.expectedReturnDate.optional(),
    })),
    defaultValues: {
      bookId: "",
      studentId: "",
      issueDate: new Date().toISOString().split('T')[0],
      expectedReturnDate: "",
      notes: "",
      status: "active",
    },
  });

  // Mutations
  const createBookMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/books", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/books"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({ title: "Success", description: "Book added successfully!" });
      addBookForm.reset();
      setIsAddBookOpen(false);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add book. Please try again." });
    },
  });

  const deleteBookMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/books/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/books"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({ title: "Success", description: "Book deleted successfully!" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete book. Please try again." });
    },
  });

  const createStudentMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/students", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({ title: "Success", description: "Student registered successfully!" });
      addStudentForm.reset();
      setIsAddStudentOpen(false);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to register student. Please try again." });
    },
  });

  const issueBookMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/issued-books", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/issued-books"] });
      queryClient.invalidateQueries({ queryKey: ["/api/books"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({ title: "Success", description: "Book issued successfully!" });
      issueBookForm.reset();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to issue book. Please try again." });
    },
  });

  const returnBookMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("PATCH", `/api/issued-books/${id}/return`, {
        returnDate: new Date().toISOString().split('T')[0],
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/issued-books"] });
      queryClient.invalidateQueries({ queryKey: ["/api/books"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({ title: "Success", description: "Book returned successfully!" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to return book. Please try again." });
    },
  });

  // Filtered data
  const filteredBooks = books?.filter(book =>
    book.title.toLowerCase().includes(bookSearchTerm.toLowerCase()) ||
    book.author.toLowerCase().includes(bookSearchTerm.toLowerCase())
  ) || [];

  const filteredStudents = students?.filter(student =>
    student.name.toLowerCase().includes(studentSearchTerm.toLowerCase()) ||
    student.studentId.toLowerCase().includes(studentSearchTerm.toLowerCase())
  ) || [];

  const availableBooks = books?.filter(book => parseInt(book.available || "0") > 0) || [];

  const filteredIssuedBooks = issuedBooks?.filter(record => {
    if (recordFilter === "active") return record.status === "active";
    if (recordFilter === "returned") return record.status === "returned";
    if (recordFilter === "overdue") {
      if (record.status === "active" && record.expectedReturnDate) {
        return new Date(record.expectedReturnDate) < new Date();
      }
      return false;
    }
    return true;
  }) || [];

  const onAddBook = (data: any) => {
    createBookMutation.mutate(data);
  };

  const onAddStudent = (data: any) => {
    createStudentMutation.mutate(data);
  };

  const onIssueBook = (data: any) => {
    const issueDate = data.issueDate;
    const expectedReturnDate = data.expectedReturnDate || 
      new Date(new Date(issueDate).getTime() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    
    issueBookMutation.mutate({
      ...data,
      expectedReturnDate,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation Header */}
      <header className="bg-card border-b border-border sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-primary text-primary-foreground p-2 rounded-lg">
                <BookOpen className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">Library Management System</h1>
                <p className="text-xs text-muted-foreground">Manage books, students & issue records</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="hidden sm:flex items-center space-x-6 text-sm">
                <a href="#books" className="text-muted-foreground hover:text-foreground transition-colors">Books</a>
                <a href="#students" className="text-muted-foreground hover:text-foreground transition-colors">Students</a>
                <a href="#records" className="text-muted-foreground hover:text-foreground transition-colors">Records</a>
              </div>
              
              <Button variant="ghost" size="icon">
                <Bell className="h-5 w-5 text-muted-foreground" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Books</p>
                  {statsLoading ? (
                    <Skeleton className="h-8 w-16 mt-2" />
                  ) : (
                    <p className="text-3xl font-bold text-foreground mt-2" data-testid="stat-total-books">
                      {stats?.totalBooks || 0}
                    </p>
                  )}
                  <p className="text-xs text-muted-foreground mt-1">Available in library</p>
                </div>
                <div className="bg-primary/10 text-primary p-3 rounded-lg">
                  <BookOpen className="h-8 w-8" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Registered Students</p>
                  {statsLoading ? (
                    <Skeleton className="h-8 w-16 mt-2" />
                  ) : (
                    <p className="text-3xl font-bold text-foreground mt-2" data-testid="stat-total-students">
                      {stats?.totalStudents || 0}
                    </p>
                  )}
                  <p className="text-xs text-muted-foreground mt-1">Active members</p>
                </div>
                <div className="bg-secondary/10 text-secondary p-3 rounded-lg">
                  <Users className="h-8 w-8" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Currently Issued</p>
                  {statsLoading ? (
                    <Skeleton className="h-8 w-16 mt-2" />
                  ) : (
                    <p className="text-3xl font-bold text-foreground mt-2" data-testid="stat-issued-books">
                      {stats?.issuedBooks || 0}
                    </p>
                  )}
                  <p className="text-xs text-muted-foreground mt-1">Active borrowings</p>
                </div>
                <div className="bg-accent/10 text-accent p-3 rounded-lg">
                  <FileText className="h-8 w-8" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Books Management Section */}
        <section id="books" className="mb-10">
          <Card className="shadow-sm overflow-hidden">
            <div className="border-b border-border bg-muted/30 px-6 py-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-semibold text-foreground">Book Management</h2>
                  <p className="text-sm text-muted-foreground mt-1">Add new books or remove existing ones</p>
                </div>
                <Dialog open={isAddBookOpen} onOpenChange={setIsAddBookOpen}>
                  <DialogTrigger asChild>
                    <Button 
                      className="font-medium text-sm" 
                      data-testid="button-add-book"
                    >
                      <Plus className="h-5 w-5 mr-2" />
                      Add Book
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md">
                    <DialogHeader>
                      <DialogTitle>Add New Book</DialogTitle>
                    </DialogHeader>
                    <Form {...addBookForm}>
                      <form onSubmit={addBookForm.handleSubmit(onAddBook)} className="space-y-5">
                        <FormField
                          control={addBookForm.control}
                          name="title"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Book Title <span className="text-destructive">*</span></FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Enter book title" 
                                  {...field} 
                                  data-testid="input-book-title"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={addBookForm.control}
                          name="author"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Author Name <span className="text-destructive">*</span></FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Enter author name" 
                                  {...field} 
                                  data-testid="input-book-author"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={addBookForm.control}
                          name="isbn"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>ISBN (Optional)</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Enter ISBN" 
                                  {...field} 
                                  data-testid="input-book-isbn"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={addBookForm.control}
                          name="publisher"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Publisher (Optional)</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Enter publisher name" 
                                  {...field} 
                                  data-testid="input-book-publisher"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={addBookForm.control}
                            name="publicationYear"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Publication Year</FormLabel>
                                <FormControl>
                                  <Input 
                                    placeholder="YYYY" 
                                    {...field} 
                                    data-testid="input-book-year"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={addBookForm.control}
                            name="quantity"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Quantity</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    min="1" 
                                    {...field} 
                                    data-testid="input-book-quantity"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="flex space-x-3 pt-2">
                          <Button 
                            type="submit" 
                            className="flex-1" 
                            disabled={createBookMutation.isPending}
                            data-testid="button-submit-book"
                          >
                            {createBookMutation.isPending ? "Adding..." : "Add Book"}
                          </Button>
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={() => setIsAddBookOpen(false)}
                          >
                            Cancel
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
            
            <div className="p-6">
              {/* Search Bar */}
              <div className="mb-6">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <Input
                    type="text"
                    placeholder="Search books by title or author..."
                    className="pl-10"
                    value={bookSearchTerm}
                    onChange={(e) => setBookSearchTerm(e.target.value)}
                    data-testid="input-search-books"
                  />
                </div>
              </div>
              
              {/* Books Table */}
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Book Title</TableHead>
                      <TableHead>Author</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {booksLoading ? (
                      Array.from({ length: 5 }).map((_, i) => (
                        <TableRow key={i}>
                          <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                          <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                          <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                          <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                          <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                        </TableRow>
                      ))
                    ) : filteredBooks.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                          No books found
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredBooks.map((book, index) => (
                        <TableRow key={book.id} data-testid={`row-book-${book.id}`}>
                          <TableCell className="text-sm text-foreground">{index + 1}</TableCell>
                          <TableCell>
                            <div className="font-medium text-foreground" data-testid={`text-book-title-${book.id}`}>
                              {book.title}
                            </div>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground" data-testid={`text-book-author-${book.id}`}>
                            {book.author}
                          </TableCell>
                          <TableCell>
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              parseInt(book.available || "0") > 0 
                                ? "bg-success/10 text-success" 
                                : "bg-accent/10 text-accent"
                            }`}>
                              {parseInt(book.available || "0") > 0 ? "Available" : "Issued"}
                            </span>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="mr-2 text-muted-foreground hover:text-foreground"
                              data-testid={`button-view-book-${book.id}`}
                            >
                              <Eye className="h-5 w-5" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="text-destructive hover:text-destructive/80"
                              onClick={() => deleteBookMutation.mutate(book.id)}
                              disabled={deleteBookMutation.isPending}
                              data-testid={`button-delete-book-${book.id}`}
                            >
                              <Trash2 className="h-5 w-5" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </div>
          </Card>
        </section>

        {/* Students and Issue Books Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-10">
          
          {/* Students Section */}
          <section id="students">
            <Card className="shadow-sm overflow-hidden">
              <div className="border-b border-border bg-muted/30 px-6 py-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-xl font-semibold text-foreground">Student Management</h2>
                    <p className="text-sm text-muted-foreground mt-1">Register new students</p>
                  </div>
                  <Dialog open={isAddStudentOpen} onOpenChange={setIsAddStudentOpen}>
                    <DialogTrigger asChild>
                      <Button 
                        variant="secondary" 
                        className="font-medium text-sm"
                        data-testid="button-add-student"
                      >
                        <Plus className="h-5 w-5 mr-2" />
                        Add Student
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-md">
                      <DialogHeader>
                        <DialogTitle>Register New Student</DialogTitle>
                      </DialogHeader>
                      <Form {...addStudentForm}>
                        <form onSubmit={addStudentForm.handleSubmit(onAddStudent)} className="space-y-5">
                          <FormField
                            control={addStudentForm.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Student Name <span className="text-destructive">*</span></FormLabel>
                                <FormControl>
                                  <Input 
                                    placeholder="Enter full name" 
                                    {...field} 
                                    data-testid="input-student-name"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={addStudentForm.control}
                            name="studentId"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Student ID</FormLabel>
                                <FormControl>
                                  <Input 
                                    placeholder="e.g., STU006" 
                                    {...field} 
                                    data-testid="input-student-id"
                                  />
                                </FormControl>
                                <p className="text-xs text-muted-foreground">Auto-generated if left blank</p>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={addStudentForm.control}
                            name="email"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Email (Optional)</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="email" 
                                    placeholder="student@example.com" 
                                    {...field} 
                                    data-testid="input-student-email"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={addStudentForm.control}
                            name="phone"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Phone Number (Optional)</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="tel" 
                                    placeholder="+91 98765 43210" 
                                    {...field} 
                                    data-testid="input-student-phone"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={addStudentForm.control}
                            name="department"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Department/Class (Optional)</FormLabel>
                                <FormControl>
                                  <Input 
                                    placeholder="e.g., Computer Science, Class 12" 
                                    {...field} 
                                    data-testid="input-student-department"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="flex space-x-3 pt-2">
                            <Button 
                              type="submit" 
                              variant="secondary" 
                              className="flex-1" 
                              disabled={createStudentMutation.isPending}
                              data-testid="button-submit-student"
                            >
                              {createStudentMutation.isPending ? "Registering..." : "Register Student"}
                            </Button>
                            <Button 
                              type="button" 
                              variant="outline" 
                              onClick={() => setIsAddStudentOpen(false)}
                            >
                              Cancel
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
              
              <div className="p-6">
                {/* Search Bar */}
                <div className="mb-6">
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Search className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <Input
                      type="text"
                      placeholder="Search students..."
                      className="pl-10"
                      value={studentSearchTerm}
                      onChange={(e) => setStudentSearchTerm(e.target.value)}
                      data-testid="input-search-students"
                    />
                  </div>
                </div>
                
                {/* Students List */}
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {studentsLoading ? (
                    Array.from({ length: 5 }).map((_, i) => (
                      <div key={i} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Skeleton className="w-10 h-10 rounded-full" />
                          <div>
                            <Skeleton className="h-4 w-24 mb-1" />
                            <Skeleton className="h-3 w-16" />
                          </div>
                        </div>
                        <Skeleton className="h-5 w-5" />
                      </div>
                    ))
                  ) : filteredStudents.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      No students found
                    </div>
                  ) : (
                    filteredStudents.map((student) => (
                      <div 
                        key={student.id} 
                        className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors"
                        data-testid={`card-student-${student.id}`}
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 rounded-full bg-secondary/20 text-secondary flex items-center justify-center font-semibold">
                            <span>{student.name.split(' ').map(n => n[0]).join('').toUpperCase()}</span>
                          </div>
                          <div>
                            <p className="font-medium text-foreground" data-testid={`text-student-name-${student.id}`}>
                              {student.name}
                            </p>
                            <p className="text-xs text-muted-foreground" data-testid={`text-student-id-${student.id}`}>
                              ID: {student.studentId}
                            </p>
                          </div>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-muted-foreground hover:text-foreground"
                          data-testid={`button-view-student-${student.id}`}
                        >
                          <Eye className="h-5 w-5" />
                        </Button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </Card>
          </section>
          
          {/* Issue Book Section */}
          <section>
            <Card className="shadow-sm overflow-hidden">
              <div className="border-b border-border bg-muted/30 px-6 py-4">
                <div>
                  <h2 className="text-xl font-semibold text-foreground">Issue Book</h2>
                  <p className="text-sm text-muted-foreground mt-1">Assign books to registered students</p>
                </div>
              </div>
              
              <div className="p-6">
                <Form {...issueBookForm}>
                  <form onSubmit={issueBookForm.handleSubmit(onIssueBook)} className="space-y-6">
                    {/* Student Selection */}
                    <FormField
                      control={issueBookForm.control}
                      name="studentId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Select Student <span className="text-destructive">*</span></FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-student">
                                <SelectValue placeholder="Choose a student..." />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {students?.map((student) => (
                                <SelectItem key={student.id} value={student.id}>
                                  {student.name} ({student.studentId})
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    {/* Book Selection */}
                    <FormField
                      control={issueBookForm.control}
                      name="bookId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Select Book <span className="text-destructive">*</span></FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-book">
                                <SelectValue placeholder="Choose a book..." />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {availableBooks.map((book) => (
                                <SelectItem key={book.id} value={book.id}>
                                  {book.title} - {book.author}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <p className="text-xs text-muted-foreground">Only available books are shown</p>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    {/* Issue Date */}
                    <FormField
                      control={issueBookForm.control}
                      name="issueDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Issue Date <span className="text-destructive">*</span></FormLabel>
                          <FormControl>
                            <Input type="date" {...field} data-testid="input-issue-date" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    {/* Expected Return Date */}
                    <FormField
                      control={issueBookForm.control}
                      name="expectedReturnDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Expected Return Date</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} data-testid="input-return-date" />
                          </FormControl>
                          <p className="text-xs text-muted-foreground">Default: 14 days from issue date</p>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    {/* Notes */}
                    <FormField
                      control={issueBookForm.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Notes (Optional)</FormLabel>
                          <FormControl>
                            <Textarea 
                              rows={3} 
                              placeholder="Add any additional notes..." 
                              {...field} 
                              data-testid="input-issue-notes"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    {/* Action Buttons */}
                    <div className="flex space-x-3 pt-2">
                      <Button 
                        type="submit" 
                        variant="accent" 
                        className="flex-1" 
                        disabled={issueBookMutation.isPending}
                        data-testid="button-issue-book"
                      >
                        <CheckCircle className="h-5 w-5 mr-2" />
                        {issueBookMutation.isPending ? "Issuing..." : "Issue Book"}
                      </Button>
                      <Button 
                        type="reset" 
                        variant="outline"
                        onClick={() => issueBookForm.reset()}
                      >
                        Clear
                      </Button>
                    </div>
                  </form>
                </Form>
              </div>
            </Card>
          </section>
        </div>

        {/* Issue Records Section */}
        <section id="records" className="mb-10">
          <Card className="shadow-sm overflow-hidden">
            <div className="border-b border-border bg-muted/30 px-6 py-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-semibold text-foreground">Issue Records</h2>
                  <p className="text-sm text-muted-foreground mt-1">Track all book issues and returns</p>
                </div>
                <div className="flex items-center space-x-3">
                  <Button variant="outline" className="font-medium text-sm">
                    <Filter className="h-5 w-5 mr-2" />
                    Filter
                  </Button>
                  <Button variant="outline" className="font-medium text-sm">
                    <Download className="h-5 w-5 mr-2" />
                    Export
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="p-6">
              {/* Filter Tabs */}
              <div className="flex space-x-2 mb-6 border-b border-border">
                <Button 
                  variant={recordFilter === "all" ? "default" : "ghost"} 
                  className="px-4 py-2 text-sm font-medium rounded-none border-b-2 border-transparent data-[active=true]:border-primary"
                  onClick={() => setRecordFilter("all")}
                  data-testid="filter-all"
                >
                  All Records
                </Button>
                <Button 
                  variant={recordFilter === "active" ? "default" : "ghost"} 
                  className="px-4 py-2 text-sm font-medium rounded-none border-b-2 border-transparent data-[active=true]:border-primary"
                  onClick={() => setRecordFilter("active")}
                  data-testid="filter-active"
                >
                  Active Issues
                </Button>
                <Button 
                  variant={recordFilter === "returned" ? "default" : "ghost"} 
                  className="px-4 py-2 text-sm font-medium rounded-none border-b-2 border-transparent data-[active=true]:border-primary"
                  onClick={() => setRecordFilter("returned")}
                  data-testid="filter-returned"
                >
                  Returned
                </Button>
                <Button 
                  variant={recordFilter === "overdue" ? "default" : "ghost"} 
                  className="px-4 py-2 text-sm font-medium rounded-none border-b-2 border-transparent data-[active=true]:border-primary"
                  onClick={() => setRecordFilter("overdue")}
                  data-testid="filter-overdue"
                >
                  Overdue
                </Button>
              </div>
              
              {/* Records Table */}
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Issue ID</TableHead>
                      <TableHead>Book Title</TableHead>
                      <TableHead>Student Name</TableHead>
                      <TableHead>Issue Date</TableHead>
                      <TableHead>Return Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {issuedBooksLoading ? (
                      Array.from({ length: 5 }).map((_, i) => (
                        <TableRow key={i}>
                          <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                          <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                          <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                          <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                          <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                          <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                          <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                        </TableRow>
                      ))
                    ) : filteredIssuedBooks.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                          No records found
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredIssuedBooks.map((record, index) => {
                        const isOverdue = record.status === "active" && record.expectedReturnDate && 
                          new Date(record.expectedReturnDate) < new Date();
                        
                        return (
                          <TableRow key={record.id} data-testid={`row-record-${record.id}`}>
                            <TableCell className="text-sm font-medium text-foreground">
                              ISS{(index + 1).toString().padStart(3, '0')}
                            </TableCell>
                            <TableCell>
                              <div className="font-medium text-foreground" data-testid={`text-record-book-${record.id}`}>
                                {record.bookTitle}
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {record.bookAuthor}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="font-medium text-foreground" data-testid={`text-record-student-${record.id}`}>
                                {record.studentName}
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {record.studentIdDisplay}
                              </div>
                            </TableCell>
                            <TableCell className="text-sm text-muted-foreground" data-testid={`text-record-issue-date-${record.id}`}>
                              {record.issueDate}
                            </TableCell>
                            <TableCell className={`text-sm ${isOverdue ? 'text-destructive font-medium' : 'text-muted-foreground'}`}>
                              {record.actualReturnDate || record.expectedReturnDate || 'N/A'}
                            </TableCell>
                            <TableCell>
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                record.status === "returned" 
                                  ? "bg-success/10 text-success"
                                  : isOverdue
                                  ? "bg-destructive/10 text-destructive"
                                  : "bg-accent/10 text-accent"
                              }`}>
                                {record.status === "returned" 
                                  ? "Returned" 
                                  : isOverdue 
                                  ? "Overdue" 
                                  : "Active"}
                              </span>
                            </TableCell>
                            <TableCell className="text-right">
                              {record.status === "active" && (
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="text-success hover:text-success/80 mr-2"
                                  title="Mark as Returned"
                                  onClick={() => returnBookMutation.mutate(record.id)}
                                  disabled={returnBookMutation.isPending}
                                  data-testid={`button-return-book-${record.id}`}
                                >
                                  <CheckCircle className="h-5 w-5" />
                                </Button>
                              )}
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="text-muted-foreground hover:text-foreground"
                                title="View Details"
                                data-testid={`button-view-record-${record.id}`}
                              >
                                <Info className="h-5 w-5" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </div>
            </div>
          </Card>
        </section>

      </main>
    </div>
  );
}
