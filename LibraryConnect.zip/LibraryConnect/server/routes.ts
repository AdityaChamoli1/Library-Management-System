import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertBookSchema, insertStudentSchema, insertIssuedBookSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Books routes
  app.get("/api/books", async (req, res) => {
    try {
      const books = await storage.getBooks();
      res.json(books);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch books" });
    }
  });

  app.post("/api/books", async (req, res) => {
    try {
      const bookData = insertBookSchema.parse(req.body);
      const book = await storage.createBook(bookData);
      res.status(201).json(book);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid book data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create book" });
      }
    }
  });

  app.delete("/api/books/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteBook(id);
      if (success) {
        res.json({ message: "Book deleted successfully" });
      } else {
        res.status(404).json({ message: "Book not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete book" });
    }
  });

  // Students routes
  app.get("/api/students", async (req, res) => {
    try {
      const students = await storage.getStudents();
      res.json(students);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch students" });
    }
  });

  app.post("/api/students", async (req, res) => {
    try {
      const studentData = insertStudentSchema.parse(req.body);
      const student = await storage.createStudent(studentData);
      res.status(201).json(student);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid student data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create student" });
      }
    }
  });

  // Issued books routes
  app.get("/api/issued-books", async (req, res) => {
    try {
      const issuedBooks = await storage.getIssuedBooks();
      res.json(issuedBooks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch issued books" });
    }
  });

  app.post("/api/issued-books", async (req, res) => {
    try {
      const issuedBookData = insertIssuedBookSchema.parse(req.body);
      const issuedBook = await storage.createIssuedBook(issuedBookData);
      res.status(201).json(issuedBook);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid issued book data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to issue book" });
      }
    }
  });

  app.patch("/api/issued-books/:id/return", async (req, res) => {
    try {
      const { id } = req.params;
      const { returnDate } = req.body;
      const success = await storage.returnBook(id, returnDate || new Date().toISOString().split('T')[0]);
      if (success) {
        res.json({ message: "Book returned successfully" });
      } else {
        res.status(404).json({ message: "Issued book not found or already returned" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to return book" });
    }
  });

  // Stats route
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
