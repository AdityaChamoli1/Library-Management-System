import { type Book, type InsertBook, type Student, type InsertStudent, type IssuedBook, type InsertIssuedBook, type IssuedBookWithDetails } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Books
  getBooks(): Promise<Book[]>;
  getBook(id: string): Promise<Book | undefined>;
  createBook(book: InsertBook): Promise<Book>;
  deleteBook(id: string): Promise<boolean>;
  updateBookAvailability(id: string, available: string): Promise<boolean>;
  
  // Students
  getStudents(): Promise<Student[]>;
  getStudent(id: string): Promise<Student | undefined>;
  getStudentByStudentId(studentId: string): Promise<Student | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  
  // Issued Books
  getIssuedBooks(): Promise<IssuedBookWithDetails[]>;
  getIssuedBook(id: string): Promise<IssuedBook | undefined>;
  createIssuedBook(issuedBook: InsertIssuedBook): Promise<IssuedBook>;
  returnBook(id: string, returnDate: string): Promise<boolean>;
  
  // Stats
  getStats(): Promise<{ totalBooks: number; totalStudents: number; issuedBooks: number; }>;
}

export class MemStorage implements IStorage {
  private books: Map<string, Book>;
  private students: Map<string, Student>;
  private issuedBooks: Map<string, IssuedBook>;

  constructor() {
    this.books = new Map();
    this.students = new Map();
    this.issuedBooks = new Map();
  }

  // Books
  async getBooks(): Promise<Book[]> {
    return Array.from(this.books.values());
  }

  async getBook(id: string): Promise<Book | undefined> {
    return this.books.get(id);
  }

  async createBook(insertBook: InsertBook): Promise<Book> {
    const id = randomUUID();
    const book: Book = { 
      id,
      title: insertBook.title,
      author: insertBook.author,
      isbn: insertBook.isbn ?? null,
      publisher: insertBook.publisher ?? null,
      publicationYear: insertBook.publicationYear ?? null,
      quantity: insertBook.quantity ?? null,
      available: insertBook.quantity ?? "1"
    };
    this.books.set(id, book);
    return book;
  }

  async deleteBook(id: string): Promise<boolean> {
    return this.books.delete(id);
  }

  async updateBookAvailability(id: string, available: string): Promise<boolean> {
    const book = this.books.get(id);
    if (book) {
      book.available = available;
      this.books.set(id, book);
      return true;
    }
    return false;
  }

  // Students
  async getStudents(): Promise<Student[]> {
    return Array.from(this.students.values());
  }

  async getStudent(id: string): Promise<Student | undefined> {
    return this.students.get(id);
  }

  async getStudentByStudentId(studentId: string): Promise<Student | undefined> {
    return Array.from(this.students.values()).find(
      (student) => student.studentId === studentId,
    );
  }

  async createStudent(insertStudent: InsertStudent): Promise<Student> {
    const id = randomUUID();
    let studentId = insertStudent.studentId;
    
    // Auto-generate student ID if not provided
    if (!studentId) {
      const studentCount = this.students.size + 1;
      studentId = `STU${studentCount.toString().padStart(3, '0')}`;
      
      // Ensure uniqueness
      while (await this.getStudentByStudentId(studentId)) {
        const nextCount = studentCount + Math.floor(Math.random() * 1000);
        studentId = `STU${nextCount.toString().padStart(3, '0')}`;
      }
    }
    
    const student: Student = {
      id,
      name: insertStudent.name,
      studentId,
      email: insertStudent.email ?? null,
      phone: insertStudent.phone ?? null,
      department: insertStudent.department ?? null
    };
    this.students.set(id, student);
    return student;
  }

  // Issued Books
  async getIssuedBooks(): Promise<IssuedBookWithDetails[]> {
    const issuedBooksArray = Array.from(this.issuedBooks.values());
    const result: IssuedBookWithDetails[] = [];
    
    for (const issuedBook of issuedBooksArray) {
      const book = await this.getBook(issuedBook.bookId);
      const student = await this.getStudent(issuedBook.studentId);
      
      if (book && student) {
        result.push({
          ...issuedBook,
          bookTitle: book.title,
          bookAuthor: book.author,
          studentName: student.name,
          studentIdDisplay: student.studentId,
        });
      }
    }
    
    return result.sort((a, b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime());
  }

  async getIssuedBook(id: string): Promise<IssuedBook | undefined> {
    return this.issuedBooks.get(id);
  }

  async createIssuedBook(insertIssuedBook: InsertIssuedBook): Promise<IssuedBook> {
    const id = randomUUID();
    const issuedBook: IssuedBook = {
      id,
      bookId: insertIssuedBook.bookId,
      studentId: insertIssuedBook.studentId,
      issueDate: insertIssuedBook.issueDate,
      expectedReturnDate: insertIssuedBook.expectedReturnDate ?? null,
      actualReturnDate: insertIssuedBook.actualReturnDate ?? null,
      status: insertIssuedBook.status ?? "active",
      notes: insertIssuedBook.notes ?? null
    };
    this.issuedBooks.set(id, issuedBook);
    
    // Update book availability
    const book = await this.getBook(insertIssuedBook.bookId);
    if (book && book.available) {
      const newAvailable = Math.max(0, parseInt(book.available) - 1).toString();
      await this.updateBookAvailability(insertIssuedBook.bookId, newAvailable);
    }
    
    return issuedBook;
  }

  async returnBook(id: string, returnDate: string): Promise<boolean> {
    const issuedBook = this.issuedBooks.get(id);
    if (issuedBook && issuedBook.status === "active") {
      issuedBook.actualReturnDate = returnDate;
      issuedBook.status = "returned";
      this.issuedBooks.set(id, issuedBook);
      
      // Update book availability
      const book = await this.getBook(issuedBook.bookId);
      if (book && book.available) {
        const newAvailable = (parseInt(book.available) + 1).toString();
        await this.updateBookAvailability(issuedBook.bookId, newAvailable);
      }
      
      return true;
    }
    return false;
  }

  async getStats(): Promise<{ totalBooks: number; totalStudents: number; issuedBooks: number; }> {
    const totalBooks = this.books.size;
    const totalStudents = this.students.size;
    const issuedBooks = Array.from(this.issuedBooks.values()).filter(
      (book) => book.status === "active"
    ).length;
    
    return { totalBooks, totalStudents, issuedBooks };
  }
}

export const storage = new MemStorage();
